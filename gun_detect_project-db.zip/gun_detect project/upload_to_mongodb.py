import os
import base64
import sys

from pymongo import MongoClient
from pymongo.server_api import ServerApi

#Example of usage 
#terminal python <code path> <image path>
#terminal: python upload_to_mongodb.py image.jpg

def checkImage(file_name):
    if file_name.lower().endswith(('.png', '.jpg', '.jpeg', '.tiff', '.bmp', '.gif')):
        return True
    return False


def checkFile(file_name):
    if (os.path.exists(file_name)):
        return True
    return False


def convert64(file_name):
    image_file = open(file_name, "rb")
    bs64_str = base64.b64encode(image_file.read())
    return bs64_str


uri = "mongodb+srv://weapon-detector.qgq5kfl.mongodb.net/?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority&appName=weapon-detector"
client = MongoClient(uri,
                     tls=True,
                     tlsCertificateKeyFile='X509-cert-3387835226083427072.pem',
                     server_api=ServerApi('1'))

db = client['keyframe'] #databaste name


def main(file_name):
    while (True):
        # check if the file exists or not in our folder
        if checkFile(file_name):
            # verify that the file is an image file
            if checkImage(file_name):
                # print(convert64(file_name))
                enc_file = convert64(file_name)
                coll = db.testcollection #collection name

                with open('base64in.txt', 'wb') as f:
                    f.write(enc_file)
                print("image conversion complete")
                coll.insert_one({"filename": file_name, "file": enc_file, "description": "test"}) #Upload to db
                print("upload successful?")
                break;
        else:
            print("Image invalid")

k = sys.argv[1]
main(k)

sys.stdout.flush()