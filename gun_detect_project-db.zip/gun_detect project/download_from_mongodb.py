import os
import base64
import sys

from pymongo import MongoClient
from pymongo.server_api import ServerApi

#Example of usage
#terminal python <code path> <image name>
#terminal: python download_from_mongodb.py image.jpg

def convert64(file_name):
    image_file = open(file_name, "rb")
    bs64_str = base64.b64encode(image_file.read())
    return bs64_str


uri = "mongodb+srv://weapon-detector.qgq5kfl.mongodb.net/?authSource=%24external&authMechanism=MONGODB-X509&retryWrites=true&w=majority&appName=weapon-detector"
client = MongoClient(uri,
                     tls=True,
                     tlsCertificateKeyFile='X509-cert-3387835226083427072.pem',
                     server_api=ServerApi('1'))

db = client['keyframe'] #databaste name


def main(file_name):
    coll = db.testcollection #collection name
    item_details = coll.find_one({"filename" : file_name},{"file"})
    print("download successful?")
    with open('base64out.txt', 'wb') as f:
        f.write(list(item_details.values())[1])
    print("image retrieved")
    newjpgtxt = open("base64out.txt","rb").read()
    g = open("out.jpg", "wb")
    g.write(base64.b64decode(newjpgtxt))
    g.close()
    print("image saved")

k = sys.argv[1]
main(k)

sys.stdout.flush()